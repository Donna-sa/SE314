<div class="billing-detail-heading">CUSTOMER DETAILS</div>

<div class="row">
	<div class="form-label inline-block">
		NAME <span class="required error"></span>

	</div>
	<div class="inline-block">
		<div id="first-name-info"></div>
		<input class="input-box-330" type="text" name="first-name"
			id="first-name">
	</div>
</div>


<div class="row">
	<div class="form-label">
		PHONE<span class="required error"></span>
	</div>
	<div class="inline-block">
		<div id="PHONE-info"></div>
		<input class="input-box-330" type="text" name="PHONE" id="PHONE">

	</div>
</div>
