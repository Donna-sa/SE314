-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- إصدار الخادم: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `userregisteration`
--

-- --------------------------------------------------------

--
-- بنية الجدول `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- إرجاع أو استيراد بيانات الجدول `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `created_at`) VALUES
(1, 'njood', '$2y$10$Kl6txj/DHchkokCkmCXvBOnkBzpG7n7Qr/Kp6WYrvlOO0KzXFIaua', '2020-04-03 20:42:20'),
(2, 'layan', '$2y$10$XSGoh7mV6EztRbCeDRxmoObs/HpOeX85u/hubPXwtAMAGWFhL7IU6', '2020-04-04 08:55:08'),
(3, 'waad', '$2y$10$pSbKRrXwj55CygpHAzuPA.zkLyuVAYsl7ywpg/PVW1CsnucxLOF5q', '2020-04-05 12:56:21'),
(4, 'ghadeer', '$2y$10$RBEEIePpjgkYS9N/gtO4nOnNPSMY51RW5EktTu9BVj9I1WkhtIbgy', '2020-04-05 18:33:38'),
(5, 'atheer', '$2y$10$/jXFDN.ah0GzNbHnJCrhJ.W5wo51mIEVX7xzPjsq68YmbdafKASFC', '2020-04-12 22:10:14'),
(6, 'LYYLYY2020@GMAIL.COM', '$2y$10$Khs5eM9tOxgLFa3j4xq/nugWUs2o0I3/vbVRTT7tgsGj39dKxHWBm', '2020-04-13 16:54:09'),
(7, 'ghena', '$2y$10$A4I31DMoaOMrzfBRi1IhfOC8p7CT965mqEBmqDPVf9UC8C9TIe3XS', '2020-04-13 22:34:08'),
(8, 'faredah', '$2y$10$QXJN2pPOB0ZwExe0OBhBhuQdNbUh4lf.NzsprpnD.DCk6Od6rg9nK', '2020-04-17 23:43:00'),
(9, 'rahaf', '$2y$10$YxXUVI1aC7F7kFP3LRc2H.tJySLV9B/OnwXpZ.FIM7Gvb0zWvbwzO', '2020-04-18 05:38:20'),
(12, 'mohamed', '$2y$10$Gn8OdSL6susoFS2L2fq9ae1xX/Bnk5XdVg5CZ68qrYlu0n33qKGF.', '2020-04-18 06:31:56'),
(13, 'renad', '$2y$10$sj6H3L1opwDmDqEMb.15W.PYPMkLTSc6Zmm9rzkh7CEELlil7OTxO', '2020-05-01 02:26:51');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
