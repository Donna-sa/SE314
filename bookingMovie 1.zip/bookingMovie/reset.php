<head> <link rel="stylesheet" type="text/css" href="style.css"> 
<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"> 
<div class="login-box">
<div class="login-left">
<div class="body"> 
<center>
<?php


// Include config file
require_once "config.php";
 
// Define variables and initialize with empty values
$email= "";
$email_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    
          // Validate email
    if(empty(trim($_POST["email"]))){
        $email_err = "Please confirm email."; }
    elseif(!preg_match_all("(^[a-zA-Z0-9_.+-]+@[gmail]+\.[com]+$)",$_POST["email"])) {
                $email_err = "you have to entere gmail email !"."<br>";
    }else{
            // Prepare a select statement
            $sql = "SELECT email FROM users WHERE email = ?";
            
            if($stmt = mysqli_prepare($link, $sql)){
                // Bind variables to the prepared statement as parameters
                mysqli_stmt_bind_param($stmt, "s", $param_email);
                
                // Set parameters
                $param_email = trim($_POST["email"]);
                
                // Attempt to execute the prepared statement
                if(mysqli_stmt_execute($stmt)){
                    /* store result */
                    mysqli_stmt_store_result($stmt);
                    
                    if(mysqli_stmt_num_rows($stmt) == 0){
                        $email_err = "This email is not exist.";
                    } else{
                        $email = trim($_POST["email"]);
                    }
                } else{
                    echo "Oops! Something went wrong. Please try again later.";
                }
                    // Close statement
                    mysqli_stmt_close($stmt);
            }
}}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
<body style="background-color: #1a162c">
    <meta charset="UTF-8">
    <title>Reset Password</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif; }
        .wrapper{ width: 350px; padding: 20px; }
    </style>
</head>
<body>
    <div class="wrapper">
        <h2>Reset Password</h2>
        <p>Please enter your Email  to reset your password.</p>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post"> 
            <div class="form-group <?php echo (!empty($email_err)) ? 'has-error' : ''; ?>">
                <label>Email</label>
                <input type="text" name="email" class="form-control" value="<?php echo $email; ?>">
                <span class="help-block"><?php echo $email_err; ?></span>
            </div>
            <div class="form-group">
                <input class="form-control button" type="submit" name="check-email" value="Continue">
                <a class="btn btn-link" href="welcome.php">Cancel</a>
            </div>
        </form>
    </div>    
</body>
</html></center>

<?php 
session_start();

$email = "";
$name = "";
$errors = array();


    //if user click continue button in forgot password form
    if(isset($_POST['email'])){
        $email = mysqli_real_escape_string($link, $_POST['email']);
        $sql = "SELECT * FROM users WHERE email='$email'";
        $stmt = mysqli_query($link, $sql);
        if(mysqli_num_rows($stmt) > 0){
            $code = rand(999999, 111111);
            $insert_code = "UPDATE users SET code = $code WHERE email = '$email'";
            $run_query =  mysqli_query($link, $insert_code);
            if($run_query){
                $subject = "Password Reset Code";
                $message = "Your password reset code is $code";
                $sender = "From: athirlocalhost@gmail.com";
                if(mail($email, $subject, $message, $sender)){
                    $info = "We've sent a passwrod reset otp to your email - $email";
                    $_SESSION['info'] = $info;
                    $_SESSION['email'] = $email;
                    header('location: welcome.php');
                    exit();
                }else{
                    $errors['otp-error'] = "Failed while sending code!";
                }
            }else{
                $errors['db-error'] = "Something went wrong!";
            }
        }else{
            $errors['email'] = "This email address does not exist!";
        }
    }

